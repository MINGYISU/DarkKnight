#include "Water.h"

int Water::changeAtk() { return 0; }

int Water::changeDef() { return 0; }

Water::~Water() {}
