# ChamberCrawler3000
git status 查看已经修改但还没有加入stage的文件
git branch 查看local的所有branch的list
git checkout [branch-name] 切换branch
git add [filename] 把想要修改或添加的文件加入stage
git commit 把新加的文件加到branch
git push 把本次修改的文件更新到remote
git pull 把remote修改的文件更新到local

