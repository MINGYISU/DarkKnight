#include "shade.h"

Shade::Shade(Map *p, int x, int y, std::string r):
    Player{p, x, y, 125, 25, 25, r} {}

