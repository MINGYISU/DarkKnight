#include "troll.h"

Troll::Troll(Map *p, int x, int y, std::string r):
    Player{p, x, y, 120, 25, 15, r} {}

