#include "blank.h"

char Blank::charAt(int xCor, int yCor){
    return ' ';
}



