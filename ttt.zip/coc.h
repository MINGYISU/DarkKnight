#ifndef COC_H
#define COC_H

class ChamberOfCommerce {
    bool manhunt;
    public:
        ChamberOfCommerce();
        void warning();
        bool wanted();
};

#endif
