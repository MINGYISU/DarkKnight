#include "PotEffect.h"
using namespace std;

PotEffect::~PotEffect() {}
